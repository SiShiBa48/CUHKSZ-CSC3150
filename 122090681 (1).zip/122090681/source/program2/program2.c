#include <linux/module.h>
#include <linux/sched.h>
#include <linux/pid.h>
#include <linux/kthread.h>
#include <linux/kernel.h>
#include <linux/err.h>
#include <linux/slab.h>
#include <linux/printk.h>
#include <linux/jiffies.h>
#include <linux/kmod.h>
#include <linux/fs.h>

MODULE_LICENSE("GPL");

/* for kthread_create */
static struct task_struct *task;

/* for do_wait parameters usage */
struct wait_opts {
    enum pid_type wo_type; //It is defined in ‘/include/linux/pid.h’.
    int wo_flags; //Wait options. (0, WNOHANG, WEXITED, etc.)
    struct pid *wo_pid; //Kernel's internal notion of a process identifier. “Find_get_pid()”
   
    struct siginfo __user *wo_info; //Singal information.
    int __user *wo_stat; // Child process’s termination status
    struct rusage __user *wo_rusage; //Resource usage
    wait_queue_entry_t child_wait; //Task wait queue
    int notask_error;
};


/* exported functions from kernel */
extern pid_t kernel_clone(struct kernel_clone_args *args);
extern int do_execve(struct filename *filename, const char __user *const __user *__argv, const char __user *const __user *__envp);
extern struct filename *getname_kernel(const char *filename);
extern long do_wait(struct wait_opts *wo);

/* func declaration */
int my_exec(void);
int my_fork(void *argc);

/* execute the test program */
int my_exec(void)
{
	int re;
	//const char path[] = "/home/vagrant/program3/test";
	const char path[] = "/tmp/test";

	struct filename *file_name = getname_kernel(path);

	/* execute a test program in child process */
	re = do_execve(file_name, NULL, NULL);
	printk("[program2] : child process\n");
	if (re == 0){
		return 0;
	} else{
		do_exit(re);
	}

}

int status;

void start_wait(pid_t pid, struct pid *wo_pid){
	struct wait_opts wo;
    enum pid_type type;
    type = PIDTYPE_PID;
    wo.wo_type = type;
    wo.wo_pid = wo_pid;
    wo.wo_flags = WEXITED;
    wo.wo_info = NULL;
    wo.wo_stat = (int __user*)&status;
    wo.wo_rusage = NULL;

    int a;
    a = do_wait(&wo);
	status = wo.wo_stat;
	return;
}

void output(int exit){
	int signal = exit & 0x7F;
	switch (signal){
		case 0:
			printk("[program2] : child process exit normally\n");
            printk("[program2] : The return signal is 0\n");
            break;
		case 1:
			printk("[program2] : get SIGHUP signal\n");
			printk("[program2] : child process terminated\n");
            printk("[program2] : The return signal is 1\n");
            break;
		case 2:
			printk("[program2] : get SIGINT signal\n");
			printk("[program2] : child process terminated\n");
            printk("[program2] : The return signal is 2\n");
            break;
		case 3:
			printk("[program2] : get SIGQUIT signal\n");
			printk("[program2] : child process terminated\n");
            printk("[program2] : The return signal is 3\n");
            break;
		case 4:
			printk("[program2] : get SIGILL signal\n");
			printk("[program2] : child process terminated\n");
            printk("[program2] : The return signal is 4\n");
            break;
		case 5:
			printk("[program2] : get SIGTRAP signal\n");
			printk("[program2] : child process terminated\n");
            printk("[program2] : The return signal is 5\n");
            break;
		case 6:
			printk("[program2] : get SIGABRT signal\n");
			printk("[program2] : child process terminated\n");
            printk("[program2] : The return signal is 6\n");
            break;
		case 7:
			printk("[program2] : get SIGBUS signal\n");
			printk("[program2] : child process terminated\n");
            printk("[program2] : The return signal is 1\n");
            break;
		case 8:
			printk("[program2] : get SIGFPE signal\n");
			printk("[program2] : child process terminated\n");
            printk("[program2] : The return signal is 8\n");
            break;
		case 9:
			printk("[program2] : get SIGKILL signal\n");
			printk("[program2] : child process terminated\n");
            printk("[program2] : The return signal is 9\n");
            break;
		case 11:
			printk("[program2] : get SIGSEGV signal\n");
			printk("[program2] : child process terminated\n");
            printk("[program2] : The return signal is 11\n");
            break;
		case 13:
			printk("[program2] : get SIGPIPE signal\n");
			printk("[program2] : child process terminated\n");
            printk("[program2] : The return signal is 13\n");
            break;
		case 14:
			printk("[program2] : get SIGALRM signal\n");
			printk("[program2] : child process terminated\n");
            printk("[program2] : The return signal is 14\n");
            break;
		case 15:
			printk("[program2] : get SIGTERM signal\n");
			printk("[program2] : child process terminated\n");
            printk("[program2] : The return signal is 15\n");
            break;
		case 127:
			printk("[program2] : get stop signal\n");
			printk("[program2] : child process stopped\n");
			printk("[program2] : The return signal is 127\n");
			break;
	}
	return;
}
// implement fork function
int my_fork(void *argc)
{
	int pid;

	// set default sigaction for current process
	int i;
	struct k_sigaction *k_action = &current->sighand->action[0];
	for (i = 0; i < _NSIG; i++)
	{
		k_action->sa.sa_handler = SIG_DFL;
		k_action->sa.sa_flags = 0;
		k_action->sa.sa_restorer = NULL;
		sigemptyset(&k_action->sa.sa_mask);
		k_action++;
	}

	/* for kernel_clone parameter usage */
	struct kernel_clone_args clone_args = {
		.flags = SIGCHLD,
		.pidfd = NULL,		// pidfd is a flag used to indicate whether to create a pidfd file descriptor when cloning a new process
		.child_tid = NULL,	// used for clone() to point to user space mem. in child process address space
		.parent_tid = NULL, // used for clone() to point to user space mem. in parent process address
		.exit_signal = SIGCHLD,
		.stack = (unsigned long)&my_exec, // the location of the function to execute
		.stack_size = 0,					// normally set as 0 because it is unused
		.tls = 0
	};

	/* fork a process using kernel_clone or kernel_thread */
	pid = kernel_clone(&clone_args);
	printk("[program2] : The child process has pid = %d\n", pid);
	printk("[program2] : This is the parent process, pid = %d\n", (int)current->pid);

	/* wait_opts paramters */

	struct pid *wo_pid = NULL;
	wo_pid = find_get_pid(pid);
	/* wait_opts settings */
	start_wait(pid, wo_pid);
	put_pid(wo_pid);
	output(status);
	/* check child process' termination status and signal */
	return 0;
	do_exit(0);
}

static int __init program2_init(void)
{

	printk("[program2] : module_init\n");

	/* create a kernel thread to run my_fork */
	printk("[program2] : module_init create kthread start\n");
	task = kthread_create(&my_fork, NULL, "Thread");

	/* wake up new thread if ok */
	if (!IS_ERR(task))
	{
		printk("[program2] : module_init kthread start\n");
		wake_up_process(task);
	}

	return 0;
}

static void __exit program2_exit(void)
{
	printk("[program2] : module_exit\n");
}

module_init(program2_init);
module_exit(program2_exit);
