#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <signal.h>

int main(int argc, char *argv[]){

    /* fork a child process */
    int status;
    pid_t pid;
    printf("Process start to fork\n");
    pid = fork();
    //fork failed
    if (pid == -1) {
        perror("fork");
        exit(1);
    }
    // child process
    if (pid == 0) { 
        char *arg[argc];
        for (int i = 0; i < argc - 1; i++) {
            arg[i] = argv[i + 1];
        }
        arg[argc - 1] = NULL;

        /* execute test program */
        printf("I'm the Child process, my pid = %d\n", getpid());
        printf("Child process start to execute test program:\n");
        execve(arg[0], arg, NULL);
        exit(SIGCHLD);
    }
    // parent process
    printf("I'm the parent process, my pid = %d\n", getpid());

    /* wait for child process terminates */
    waitpid(-1, &status, WUNTRACED);

    printf("Parent process receives the SIGCHLD signal\n");

    /* check child process'  termination status */
    if(WIFEXITED(status)){ // normal exit
        printf("Normal termination with EXIT STATUS = %d\n",WEXITSTATUS(status));
    }else if(WIFSTOPPED(status)){ // stop signal
        printf("child process get SIGSTOP signal\n");
    }else if(WIFSIGNALED(status)){ // abnormal exit
        outputsignal(WTERMSIG(status));
    }else{
        printf("CHILD PROCESS CONTINUED\n");
    }
    exit(0);
}

void outputsignal(int num){
    switch (num){
        case 1: 
            printf("child process get SIGHUP signal\n");
            break;
        case 2:
            printf("child process get SIGINT signal\n");
            break;
        case 3: 
            printf("child process get SIGQUIT signal\n");
            break;
        case 4: 
            printf("child process get SIGILL signal\n");
            break;     
        case 5:
            printf("child process get SIGTRAP signal\n");
            break;               
        case 6: 
            printf("child process get SIGABRT signal\n");
            break;
        case 7: 
            printf("child process get SIGBUS signal\n");
            break;            
        case 8:
            printf("child process get SIGFPE signal\n");
            break;
        case 9:
            printf("child process get SIGKILL signal\n");
            break;
        case 11:
            printf("child process get SIGSEGV signal\n");
            break;
        case 13: 
            printf("child process get SIGPIPE signal\n");
            break;        
        case 14:
            printf("child process get SIGALRM signal\n");
            break;        
        case 15: 
            printf("child process get SIGTERM signal\n");
            break;

    }
}
