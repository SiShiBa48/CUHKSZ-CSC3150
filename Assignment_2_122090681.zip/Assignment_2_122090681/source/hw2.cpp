#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <termios.h>
#include <fcntl.h>

/* const numbers define */
#define ROW 17
#define COLUMN 49
#define HORI_LINE '-'
#define VERT_LINE '|'
#define CORNER '+'
#define PLAYER '0'
#define WALLLENGTH 15
#define WALLSPEED 500000

/* global variables */
int player_x;
int player_y;
char map[ROW][COLUMN + 1];
pthread_mutex_t mutex;
int gamestatus;
int wallposition[6],coinposition[6];
int coin[6] = {1, 3, 5, 11, 13, 15};
int wall[6] = {2, 4, 6, 10, 12, 14};
int keycounteridx[6] = {1,1,1,1,1,1};
int keycounter = 6;

/* functions */
int kbhit(void);
void map_print(void);

/* Determine a keyboard is hit or not.
 * If yes, return 1. If not, return 0. */
int kbhit(void)
{
    struct termios oldt, newt;
    int ch;
    int oldf;
    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;
    newt.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
    oldf = fcntl(STDIN_FILENO, F_GETFL, 0);
    fcntl(STDIN_FILENO, F_SETFL, oldf | O_NONBLOCK);
    ch = getchar();
    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
    fcntl(STDIN_FILENO, F_SETFL, oldf);
    if (ch != EOF)
    {
        ungetc(ch, stdin);
        return 1;
    }
    return 0;
}

/* print the map */
void map_print(void)
{
    printf("\033[H\033[2J");
    int i;
    for (i = 0; i <= ROW - 1; i++)
        puts(map[i]);
}

void initcreation(void){
    int start,k;
    for (int i = 0; i < 6; i++){
        k = rand() % 2;
        if (k == 0){
            wallposition[i] = -1;
        }else{
            wallposition[i] = 1;
        }
        start = rand() % (COLUMN-2);
        for (int j = 0; j < WALLLENGTH; j++){
            map[wall[i]][(start+j)%(COLUMN-2)+1] = '=';
        }
    }
    for (int i = 0; i < 6; i++){
        k = rand() % 2;
        if (k == 0){
            coinposition[i] = -1;
        }else{
            coinposition[i] = 1;
        }
        start = rand() % (COLUMN-2);
        map[coin[i]][start+1] = '$';
    }
}

void stopgame(void){
	printf("\033[H\033[2J");
	if(gamestatus == 1){
		printf("You lose the game!!\n");
	}
	else if(gamestatus == 2){
		printf("You win the game!!\n");
	}
	else{
		printf("You exit the game.\n");
	}
}

void *move (void *t){
    int logId = (long) t;
    bool wallhit = false; 
    char currow[COLUMN-2];
    if (!logId){
        while(!gamestatus){
            usleep(WALLSPEED);
            pthread_mutex_lock(&mutex);
            wallhit = false;
            map[player_x][player_y] = ' ';
            for (int i = 0; i < 6; i++){
                for (int a = 0; a < COLUMN-2; a++){
                    currow[a] = ' ';
                }
                for (int a = 0; a < COLUMN-2; a++){
                    currow[(a + wallposition[i]+47) % 47] = map[wall[i]][a+1];
                }
                for (int j = 0; j < COLUMN-2; j++){
                    map[wall[i]][j+1] = currow[j];
                }
                if (map[player_x][player_y] == '='){
                    gamestatus = 1;
                    pthread_mutex_unlock(&mutex);
                    break;
                }
            }
            for (int i = 0; i < 6; i++){
                for (int a = 0; a < COLUMN-2; a++){
                    currow[a] = ' ';
                }
                for (int a = 0; a < COLUMN-2; a++){
                    currow[(a + coinposition[i] + 47) % 47] = map[coin[i]][a+1];
                }
                for (int j = 0; j < COLUMN-2; j++){
                    map[coin[i]][j+1] = currow[j];
                }
                if (map[player_x][player_y] == '$'){
                    for (int k = 0; k<6; k++){
                        if ((player_x == coin[k])&&(keycounteridx[k]==1)){
                            keycounteridx[k] = 0;
                            keycounter--;
                        }
                    }
                    map[player_x][player_y] = ' ';
                }
                if (keycounter == 0){
                    gamestatus= 2;
					pthread_mutex_unlock(&mutex);
					break;
                }
            }
            map[player_x][player_y] = '0';
            map_print();
            pthread_mutex_unlock(&mutex);
        }
        pthread_exit(NULL);
    }else{
        char laststep = ' '; 
        bool change = false;
        while (!gamestatus){
            pthread_mutex_lock(&mutex);
            if (kbhit()){
                char currentStep;
				char dir = getchar();
				int curx = player_x;
				int cury = player_y;
                if(dir == 27){
					while (kbhit()!=0)
					{
						dir = getchar();
					}
					pthread_mutex_unlock(&mutex);
					continue;
				}
                change = false;
				if( dir == 'q' || dir == 'Q' ){	
					gamestatus = 4;
					pthread_mutex_unlock(&mutex);
					break;
				}
                if( dir == 'w' || dir == 'W' ){
					player_x--;
					change = true;
                    if (player_x == 0){
                        gamestatus= 1;
						pthread_mutex_unlock(&mutex);
						break;
                    }
				}
                if( dir == 'a' || dir == 'A' ){
					player_y--;
					change = true;
                    if (player_y == 0){
                        gamestatus= 1;
						pthread_mutex_unlock(&mutex);
						break;
                    }
				}
                if( dir == 'd' || dir == 'D' ){
					player_y++;
					change = true;
                    if (player_y == COLUMN - 1){
                        gamestatus= 1;
						pthread_mutex_unlock(&mutex);
						break;
                    }
				}
                if( dir == 's' || dir == 'S' ){
					player_x++;
					change = true;
                    if (player_x == ROW -1){
                        gamestatus= 1;
						pthread_mutex_unlock(&mutex);
						break;
                    }
				}
                if (map[player_x][player_y] == '$'){
                    for (int i = 0; i<6; i++){
                        if ((player_x == coin[i])&&(keycounteridx[i]==1)){
                            keycounteridx[i] = 0;
                            keycounter--;
                        }
                    }
                    map[player_x][player_y] = ' ';
                }
                if (keycounter == 0){
                    gamestatus= 2;
					pthread_mutex_unlock(&mutex);
					break;
                }

                map[curx][cury] = laststep;
                laststep = map[player_x][player_y];
                map[player_x][player_y] = '0';

                if (change){
                    map_print();
                }
            }
            pthread_mutex_unlock(&mutex);
        }
        pthread_exit(NULL);
    }
}

/* main function */
int main(int argc, char *argv[])
{
    gamestatus = 0;
    srand(time(NULL));
    int i, j,rc1,rc2,rc3;
    pthread_t threadwall, threadminer;
    pthread_mutex_init(&mutex, NULL);
    /* initialize the map */
    memset(map, 0, sizeof(map));
    for (i = 1; i <= ROW - 2; i++)
    {
        for (j = 1; j <= COLUMN - 2; j++)
        {
            map[i][j] = ' ';
        }
    }
    for (j = 1; j <= COLUMN - 2; j++)
    {
        map[0][j] = HORI_LINE;
        map[ROW - 1][j] = HORI_LINE;
    }
    for (i = 1; i <= ROW - 2; i++)
    {
        map[i][0] = VERT_LINE;
        map[i][COLUMN - 1] = VERT_LINE;
    }
    map[0][0] = CORNER;
    map[0][COLUMN - 1] = CORNER;
    map[ROW - 1][0] = CORNER;
    map[ROW - 1][COLUMN - 1] = CORNER;

    player_x = ROW / 2;
    player_y = COLUMN / 2;
    map[player_x][player_y] = PLAYER;

    initcreation();
    map_print();

    rc1 = pthread_create(&threadwall, NULL, move, (void*) 0);
    rc2 = pthread_create(&threadminer, NULL, move, (void*) 1);
    
    if (rc1){
        printf("ERROR: return code from pthread_create() is %d", rc1);
		exit(1);
    }
    if (rc2){
        printf("ERROR: return code from pthread_create() is %d", rc2);
		exit(1);
    }

    pthread_join(threadminer, NULL);
    pthread_join(threadwall, NULL);

    stopgame();

    pthread_mutex_destroy(&mutex);
	pthread_exit(NULL);
    return 0;
}
